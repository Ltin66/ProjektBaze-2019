//
// Created by tin on 12/22/19.
//

#ifndef VETAPP_1_0_UI_MENU_RACUNOVODA_H
#define VETAPP_1_0_UI_MENU_RACUNOVODA_H


#include "../ui_main.h"

#include "../dbUpiti.h"
#include "../dbTablice.h"
#include "../dbConnection.h"
#include "../ui_user.h"

#include <list>
#include <vector>
#include <algorithm>




int uiUserRacunovodaMainMenu(SAConnection &con,korisnik &kor);





#endif //VETAPP_1_0_UI_MENU_RACUNOVODA_H
